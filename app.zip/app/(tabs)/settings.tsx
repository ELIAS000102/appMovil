import React from 'react'
import SettingScreen from '../../screens/settingScreen'

export default function settings() {
  return (
    <SettingScreen />
  )
}