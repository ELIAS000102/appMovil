import React from 'react'
import HomeScreen from '../../screens/homeScreen'

export default function Home() {
  return (
    <HomeScreen />
  )
}