import React from 'react'
import UserScreen from '..//../screens/userScreen'

export default function user() {
  return (
    <UserScreen/>
  )
}